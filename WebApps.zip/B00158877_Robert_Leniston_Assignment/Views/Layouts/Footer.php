<hr>
<footer class="bg-light mt-5 py-3">
        <div class="container">
            <div class="row">
            <div class="col-md-4">
                <h5> BookStore</h5>
                <p>Online Bookstore</p>
            </div>
            <div class="col-md-4">
                <h5> Contact </h5>
                <p>Contact@bookstore.ie
                    <br>
                Phone:01 424-000</p>
            </div>
            <div class="col-md-4">
                <a href="#" class="btn btn-secondary"> Back to top </a>
            </div>
            </div>
        </div>
</footer>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

